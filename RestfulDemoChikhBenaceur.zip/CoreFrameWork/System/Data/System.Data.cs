﻿namespace System.Data
{
  public enum SortOrder
  {
    Unspecified = -1,
    Ascending = 0,
    Descending = 1,
  }

}
