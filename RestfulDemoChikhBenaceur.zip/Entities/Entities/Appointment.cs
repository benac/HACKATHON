﻿using Entities.Shared;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entities
{

  [Table("Appointments")]
  public class Appointment : Entity
  {
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public Int32 Id { get; set; }

    [Required]
    public String ClientFullName { get; set; }

   [Required]
   public String Date { get; set; }

   [ForeignKey("CenterId")]
   public Center Center { get; set; }
    }
}
