﻿using Entities.Shared;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entities
{

  [Table("Centers")]
  public class Center : Entity
  {
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public Int32 Id { get; set; }

    [Required]
    public String Name { get; set; }

    [Required]
    public String StreetAddress { get; set; }

    [ForeignKey("CenterTypeId")]
    public CenterType CenterType { get; set; }

    }
}
