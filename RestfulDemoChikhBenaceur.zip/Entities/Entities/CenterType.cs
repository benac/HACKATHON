﻿using Entities.Shared;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Entities
{

  [Table("CenterTypes")]
  public class CenterType : Entity
  {
    [Key]
    [Required]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public Int32 Id { get; set; }

    [Required]
    public String Value { get; set; }

    }
}
