﻿namespace System
{
  public class ConcurrencyException : Exception
  {
    public ConcurrencyException(String message) : base(message)
    {
    }
  }
}
