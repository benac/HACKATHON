﻿using AutoMapper;
using Entities;
using Entities.Mappings;
using Microsoft.EntityFrameworkCore;
using Resources.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Resources.Service
{
  public class AppointmentResourceService : IAppointmentResourceService, IDisposable
  {
    private readonly IMapper mapper;
    protected EntityContext EntityContext { get; private set; }

    public AppointmentResourceService(EntityContext entityContext)
    {
      EntityContext = entityContext;

      // Setup AutoMapper between Resource and Entity
      var config = new AutoMapper.MapperConfiguration(cfg =>
      {
        cfg.AddProfiles(typeof(AppointmentMapping).GetTypeInfo().Assembly);
      });

      mapper = config.CreateMapper();
    }


    /// <summary>
    ///  Perform basic validation
    /// </summary>
    /// <param name="resource"></param>
    /// <param name="errors"></param>
    protected void ValidateAttributes(AppointmentResource resource, IList<ValidationError> errors)
    {
      var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(resource);
      var validationResults = new List<ValidationResult>(); ;

      Validator.TryValidateObject(resource, validationContext, validationResults, true);

      foreach (var item in validationResults)
        errors.Add(new ValidationError(item.ErrorMessage, item.MemberNames?.FirstOrDefault() ?? ""));
    }


    protected virtual void ValidateBusinessRules(AppointmentResource resource, IList<ValidationError> errors)
    {

     //Rule: -	A TC Service Center can only accommodate one appointment per day.
     // Check if already exist an appointment in the same day 
      if (!resource.Date.IsNullOrEmpty())
      {
         var dateBooking = DateTime.ParseExact(resource.Date, "yyyy-MM-dd", CultureInfo.InvariantCulture);
         if (Items().Where(r => DateTime.ParseExact(r.Date, "yyyy-MM-dd", CultureInfo.InvariantCulture) == dateBooking).Count() > 0 )
          errors.Add(new ValidationError($"{resource.Date} is already exist an appointment for this Date", nameof(resource.Date)));
      }
    }


    protected virtual void ValidateDelete(AppointmentResource resource, IList<ValidationError> errors)
    {

    }


    public async Task<AppointmentResource> FindAsync(Int32 id)
    {
      // Fetch entity from storage
      var entity = await EntityContext.FindAsync<Appointment>(id);

      // Convert emtity to resource
      var result = mapper.Map<AppointmentResource>(entity);

      return result;
    }


    public IQueryable<AppointmentResource> Items()
    {
      var entities = Enumerable.AsEnumerable(EntityContext.Appointments);
      var result = mapper.Map<IEnumerable<Appointment>, IEnumerable<AppointmentResource>>(entities);

      return result.AsQueryable();
    }


    private IEnumerable<String> CreateFieldNames(IQueryable items, String searchFields = "")
    {
      IEnumerable<String> fieldNames = searchFields.Split(new Char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);

      IEnumerable<String> propertyNames = items.ElementType.GetProperties(BindingFlags.Public | BindingFlags.Instance).Select(p => p.Name).ToList();

      // Use only valid field names
      IEnumerable<String> result = fieldNames.Where(n => propertyNames.Contains(n)).ToList();

      return result;
    }


    // needs System.Linq.Dynamic.Core
    private IQueryable SearchItems(IQueryable items, String sortBy, String sortDirection, Int32 skip, Int32 take, String search, String searchFields)
    {
      IEnumerable<String> propertyNames = items.ElementType.GetProperties(BindingFlags.Public | BindingFlags.Instance).Select(p => p.Name).ToList();

      // Apply filtering to all visible column names
      if (!String.IsNullOrEmpty(search))
      {
        // Use only valid fieldnames
        IEnumerable<String> fieldNames = CreateFieldNames(items, searchFields);

        StringBuilder sb = new StringBuilder();

        // create dynamic Linq expression
        foreach (String fieldName in fieldNames)
          sb.AppendFormat("({0} == null ? false : {0}.ToString().IndexOf(@0, @1) >=0) or {1}", fieldName, Environment.NewLine);

        String searchExpression = sb.ToString();
        // remove last "or" occurrence
        searchExpression = searchExpression.Substring(0, searchExpression.LastIndexOf("or"));

        // Apply filtering
        items = items.Where(searchExpression, search, StringComparison.OrdinalIgnoreCase);
      }

      // Skip requires sorting, so make sure there is always sorting
      String sortExpression = "";

      if (!String.IsNullOrEmpty(sortBy))
      {
        sortExpression += String.Format("{0} {1}", sortBy, sortDirection);
        items = items.OrderBy(sortExpression);
      }
    // show  limit take
    if (take > 0)
        items = items.Skip(skip).Take(take);

      return items;
    }


    public LoadResult<AppointmentResource> Load(String sortBy, String sortDirection, Int32 skip, Int32 take, String search, String searchFields)
    {
      IQueryable entities = EntityContext.Appointments.Include(c => c.Center).AsQueryable();

      // where clause is set, count all records
      Int32 count = entities.Count();

      // Perform filtering, ordering and paging
      entities = SearchItems(entities, sortBy, sortDirection, skip, take, search, searchFields);

      // Prepare result
      var result = new LoadResult<AppointmentResource>()
      {
        CountUnfiltered = count,
        Items = mapper.Map<IList<Appointment>, IList<AppointmentResource>>(entities.ToDynamicList<Appointment>())
      };

      return result;
    }


    public async Task<ResourceResult<AppointmentResource>> InsertAsync(AppointmentResource resource)
    {
            // Fields are set by persistance service 
            resource.CreatedBy = null;

            resource.ModifiedAt = null;
            resource.ModifiedBy = null;

            resource.RowVersion = null;

            return await UpsertAsync(resource);
    }


    public async Task<ResourceResult<AppointmentResource>> UpdateAsync(AppointmentResource resource)
    {
      return await UpsertAsync(resource);
    }


    public async Task<ResourceResult<AppointmentResource>> UpsertAsync(AppointmentResource resource)
    {
      var result = new ResourceResult<AppointmentResource>();

      // save beautify effect effect 
      result.Resource = resource;

      // Apply simple validation on attribute level
      ValidateAttributes(resource, result.Errors);

      // Apply complex business rules validation
      ValidateBusinessRules(resource, result.Errors);

      // Save is only usefull when error free
      if (result.Errors.Count == 0)
      {
        // Convert resource to entity
        var entity = mapper.Map<Appointment>(resource);

        // save entity
        await EntityContext.UpsertAsync(entity);

        // convert save result back to resource and get database created values like auto incremental field and timestamps.
        result.Resource = mapper.Map<AppointmentResource>(entity);
      }

      return result;
    }


    public async Task<ResourceResult<AppointmentResource>> DeleteAsync(Int32 id)
    {
      var result = new ResourceResult<AppointmentResource>();

      // Check if resource still exists
      result.Resource = await FindAsync(id);

      if (result.Resource != null)
      {
        // Check if delete is allowed 
        ValidateDelete(result.Resource, result.Errors);

        // Delete only if allowed
        if (result.Errors.Count == 0)
        {
          var entity = mapper.Map<Appointment>(result.Resource);

          await EntityContext.DeleteAsync(entity);
        }
      }

      return result;
    }

    #region IDisposable Support
    protected virtual void Dispose(Boolean isDisposing)
    {
      if (isDisposing && EntityContext != null)
      {
        EntityContext.Dispose();
        EntityContext = null;
      }
    }

    public void Dispose()
    {
      Dispose(true);
    }
    #endregion
  }
}
