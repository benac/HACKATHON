﻿
using System;

namespace Resources.Service
{
  public class ResourceServiceConfig
  {
    public String ServerUrl { get; set; }

    public String UserId { get; set; }
    public String UserPassword { get; set; }

  }
}