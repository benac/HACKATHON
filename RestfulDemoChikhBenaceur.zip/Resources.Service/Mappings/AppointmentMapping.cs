﻿using AutoMapper;
using System;

namespace Entities.Mappings
{
  public class AppointmentMapping : Profile
  {
    public AppointmentMapping()
    {
     // 2 way mapping resource <==> entity model
      CreateMap<Resources.AppointmentResource, Appointment>();
      CreateMap<Appointment, Resources.AppointmentResource>();
    }
  }
}
