﻿using AutoMapper;
using System;

namespace Entities.Mappings
{
  public class CenterMapping : Profile
  {
    public CenterMapping()
    {
      // 2 way mapping resource <==> entity model
      CreateMap<Resources.CenterResource, Center>();
      CreateMap<Center, Resources.CenterResource>();
    }
  }
}
