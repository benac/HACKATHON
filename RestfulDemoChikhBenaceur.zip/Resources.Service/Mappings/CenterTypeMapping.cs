﻿using AutoMapper;
using System;

namespace Entities.Mappings
{
  public class CenterTypeMapping : Profile
  {
    public CenterTypeMapping()
    {
      // 2 way mapping resource <==> entity model
      CreateMap<Resources.CenterTypeResource, CenterType>();
      CreateMap<CenterType, Resources.CenterTypeResource>();
    }
  }
}
