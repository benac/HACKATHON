﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Resources;
using Resources.Service;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Reflection;
using Newtonsoft.Json;
using Resources.Shared;
using System.Net;

/// <summary>
/// Enter Point of service call for all CenterType methods
/// </summary>
namespace Data.WebApi.Controllers
{
  [Route("api/[controller]")]
  public class CenterTypeController : Controller
  {
    private readonly ICenterTypeResourceService ResourceService;

    public CenterTypeController(ICenterTypeResourceService resourceService)
    {
      ResourceService = resourceService;
    }
       

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(Int32 id)
    {
      var resource = await ResourceService.FindAsync(id);

      return (resource == null) ? NotFound() as IActionResult : Json(resource);
    }

    [HttpGet]
    public IActionResult Get(String sortBy, String sortDirection, Int32 skip, Int32 take, String search, String searchFields)
    {
      var result = ResourceService.Load(sortBy, sortDirection, skip, take, search, searchFields);
      
      return Json(result);
    }

    [HttpPost]
    public async Task<IActionResult> Post([FromBody]CenterTypeResource resource)
    {
      try
      {
        // Create rescource
        var serviceResult = await ResourceService.InsertAsync(resource);

        // if return error message if needed
        if (serviceResult.Errors.Count > 0)
          return BadRequest(serviceResult);

        // On succes return url with id and newly created resource  
        return CreatedAtAction(nameof(Get), new { id = serviceResult.Resource.Id }, serviceResult.Resource);
      }
      catch (Exception ex)
      {
        var result = new ResourceResult<CenterTypeResource>(resource);

        while (ex != null)
          result.Exceptions.Add(ex.Message);

        return BadRequest(result);
      }
    }


    [HttpPut]
    public async Task<IActionResult> Put([FromBody]CenterTypeResource resource)
    {
      try
      {
        var currentResource = await ResourceService.FindAsync(resource.Id);

        if (currentResource == null)
          return NotFound();

        var serviceResult = await ResourceService.UpdateAsync(resource);

        if (serviceResult.Errors.Count > 0)
          return BadRequest(serviceResult);

        return Ok(serviceResult.Resource);
      }
      catch (Exception ex)
      {
        var result = new ResourceResult<CenterTypeResource>(resource);

        while (ex != null)
        {
          result.Exceptions.Add(ex.Message);

          if (ex is ConcurrencyException)
            return StatusCode(HttpStatusCode.Conflict.ToInt32(), result);

          ex = ex.InnerException;
        }

        return BadRequest(result);
      }
    }


    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Int32 id)
    {
      try
      {
        var serviceResult = await ResourceService.DeleteAsync(id);

        if (serviceResult.Resource == null)
          return NoContent();

        if (serviceResult.Errors.Count > 0)
          return BadRequest(serviceResult);

        return Ok();
      }
      catch (Exception ex)
      {
        var result = new ResourceResult<CenterTypeResource>();

        while (ex != null)
          result.Exceptions.Add(ex.Message);

        return BadRequest(result);
      }
    }
  }
}