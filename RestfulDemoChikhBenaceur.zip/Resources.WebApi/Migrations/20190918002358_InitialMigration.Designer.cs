﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Entities;

namespace Resources.WebApi.Migrations
{
    [DbContext(typeof(EntityContext))]
    [Migration("20190918002358_InitialMigration")]
    partial class InitialMigration
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("Entities.Appointment", b =>
                {
                    b.Property<int>("Id");

                    b.Property<int>("CenterId");

                    b.Property<string>("ClientFullName")
                        .IsRequired();

                    b.Property<DateTime>("CreatedAt");

                    b.Property<string>("CreatedBy")
                        .HasMaxLength(128);

                    b.Property<string>("Date")
                        .IsRequired();

                    b.Property<DateTime?>("ModifiedAt");

                    b.Property<string>("ModifiedBy")
                        .HasMaxLength(128);

                    b.Property<string>("RowVersion")
                        .HasMaxLength(40);

                    b.HasKey("Id");

                    b.HasIndex("CenterId");

                    b.ToTable("Appointments");
                });

            modelBuilder.Entity("Entities.Center", b =>
                {
                    b.Property<int>("Id");

                    b.Property<int>("CenterTypeId");

                    b.Property<DateTime>("CreatedAt");

                    b.Property<string>("CreatedBy")
                        .HasMaxLength(128);

                    b.Property<DateTime?>("ModifiedAt");

                    b.Property<string>("ModifiedBy")
                        .HasMaxLength(128);

                    b.Property<string>("Name")
                        .IsRequired();

                    b.Property<string>("RowVersion")
                        .HasMaxLength(40);

                    b.Property<string>("StreetAddress")
                        .IsRequired();

                    b.HasKey("Id");

                    b.HasIndex("CenterTypeId");

                    b.ToTable("Centers");
                });

            modelBuilder.Entity("Entities.CenterType", b =>
                {
                    b.Property<int>("Id");

                    b.Property<DateTime>("CreatedAt");

                    b.Property<string>("CreatedBy")
                        .HasMaxLength(128);

                    b.Property<DateTime?>("ModifiedAt");

                    b.Property<string>("ModifiedBy")
                        .HasMaxLength(128);

                    b.Property<string>("RowVersion")
                        .HasMaxLength(40);

                    b.Property<string>("Value")
                        .IsRequired();

                    b.HasKey("Id");

                    b.ToTable("CenterTypes");
                });

            modelBuilder.Entity("Entities.Appointment", b =>
                {
                    b.HasOne("Entities.Center", "Center")
                        .WithMany()
                        .HasForeignKey("CenterId")
                        .OnDelete(DeleteBehavior.Cascade);
                });

            modelBuilder.Entity("Entities.Center", b =>
                {
                    b.HasOne("Entities.CenterType", "CenterType")
                        .WithMany()
                        .HasForeignKey("CenterTypeId")
                        .OnDelete(DeleteBehavior.Cascade);
                });
        }
    }
}
