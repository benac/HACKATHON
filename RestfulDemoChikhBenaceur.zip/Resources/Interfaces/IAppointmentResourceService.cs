﻿using Resources.Shared;
using System;

namespace Resources.Service
{
  public interface IAppointmentResourceService : IResourceService<AppointmentResource, Int32>
  {
  }

}
