﻿using Resources.Shared;
using System;

namespace Resources.Service
{
  public interface ICenterResourceService : IResourceService<CenterResource, Int32>
  {
  }

}
