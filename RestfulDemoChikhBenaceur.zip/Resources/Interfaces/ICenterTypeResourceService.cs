﻿using Resources.Shared;
using System;

namespace Resources.Service
{
  public interface ICenterTypeResourceService : IResourceService<CenterTypeResource, Int32>
  {
  }

}
