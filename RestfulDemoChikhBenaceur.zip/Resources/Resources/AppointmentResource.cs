﻿using Resources.Shared;
using System;
using System.ComponentModel.DataAnnotations;

namespace Resources
{

  public class AppointmentResource : Resource<Int32>
  {    
    [Required]
    public override Int32 Id { get; set; }

        [Required]
        public String ClientFullName { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}")]
        public String Date { get; set; }

        // Include Center
        public CenterResource Center { get; set; }

    }
}
