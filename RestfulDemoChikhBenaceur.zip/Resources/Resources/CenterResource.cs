﻿using Resources.Shared;
using System;
using System.ComponentModel.DataAnnotations;

namespace Resources
{

  public class CenterResource : Resource<Int32>
  {    
    [Required]
    public override Int32 Id { get; set; }

     public String Name { get; set; }

      public String StreetAddress { get; set; }

      public CenterTypeResource CenterType { get; set; }

    }
}
