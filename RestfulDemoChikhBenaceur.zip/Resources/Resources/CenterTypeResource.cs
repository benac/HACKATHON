﻿using Resources.Shared;
using System;
using System.ComponentModel.DataAnnotations;

namespace Resources
{

  public class CenterTypeResource : Resource<Int32>
  {    
    [Required]
    public override Int32 Id { get; set; }

     [Required]
     public String Value { get; set; }

    }
}
