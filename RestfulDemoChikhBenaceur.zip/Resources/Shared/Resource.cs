﻿using System;

namespace Resources.Shared
{
  public class Resource<TKey> where TKey : IEquatable<TKey>
  {
    virtual public TKey Id { get; set; }

        public String CreatedBy { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime? ModifiedAt { get; set; }

        public String ModifiedBy { get; set; }

        // as the web service can be used simultaneously, this will manage the concurrency access
        public String RowVersion { get; set; }
    }
}
