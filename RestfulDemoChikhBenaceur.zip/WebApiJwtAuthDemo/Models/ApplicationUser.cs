﻿namespace WebApiJwtAuthDemo.Models
{
  public class JwtUser
  {
    public string UserName { get; set; }
    public string Password { get; set; }
  }
}