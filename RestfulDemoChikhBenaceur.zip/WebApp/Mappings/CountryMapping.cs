﻿using AutoMapper;
using Models;

namespace Models.Mappings
{
  public class CountryMapping : Profile
  {
    public CountryMapping()
    {
      // 2 way mapping resource <==> ViewModel
      CreateMap<Resources.CountryResource, CountryModel>();
      CreateMap<CountryModel, Resources.CountryResource>();
    }
  }
}
