﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Models
{
  public class CountryModel
  {
    public Int32 Id { get; set; }

    public String Code2 { get; set; }

    [MaxLength(3)]
    public String Code3 { get; set; }

    public String Name { get; set; }

    public String RowVersion { get; set; }
  }
}
